<template>
  <div v-if="!!mapTypeData" class="type well">
    <div v-for="(mapType, index) in mapTypeData" :key="index">
      <mapTypeIcon :src="mapType.src"/>
      <mapTypeDescription :descript="mapType.descript" @click="$emit('change-mapLayers',$event)" />
    </div>
  </div>
</template>

<script>
import mapTypeIcon from "./MapTypeItemImageIcon";
import mapTypeDescription from "./MapTypeItemDescription";


export default {
  components: {
    mapTypeIcon,
    mapTypeDescription
  },
  props: {
    mapTypeData: {
      type: Array,
      required: true
    }
  }
};
</script>

<style scoped>
.type {
  border: 1px solid #000;
  padding: 10px;
  width: 100px;/*
  position: absolute;
  right: 150px;
  display: none;*/
}
</style>
