<template>
  <div>
    <MapTypeSelector id="choose-map" v-on:show-map-base="showMapSelect">Choose Map Type</MapTypeSelector>
    <MapTypElements @click="$emit('change-mapLayers',$event)"
      :mapTypeData="mapTypeData"
      id="base-maps"
      :class="[showBase ? 'show-bases' : 'hide-bases']"
    />

  </div>
</template>

<script>
import MapTypeSelector from "./MapTypeSelector";
import MapTypElements from "./MapType";
import maptypItem from './MapTypeItem';
export default {
  name: "ToggleMap",
  components: {
    MapTypeSelector,
    MapTypElements
  },
  data() {
    return {
      showBase: false
     
    };
  },
  methods: {
    showMapSelect() {
      this.showBase = !this.showBase;
    }
  },
  props: {
    mapTypeData: {
      type: Array
    }
  }
};
</script>

<style scoped>
#choose-map {
  position: absolute;
  right: 10px;
}
#base-maps {
  position: absolute;
  right: 200px;
}

.show-bases {
  display: block !important;
}
.hide-bases {
  display: none !important;
}
</style>
