<template>
  <div v-if="!!itemData"  class="map-type">
    <imageIcon :src="itemData.image"/>
    <description :descript="itemData.description" @click="$emit('change-mapLayers',$event)"/>
  </div>
</template>

<script>
import imageIcon from './MapTypeItemImageIcon';
import description from './MapTypeItemDescription';
export default {
  name: "map-type-item",
  components: {
      imageIcon,
      description
  },
  props: {
    itemData: Object,
    required:true,
  }
};
</script>

<style scoped>
.map-type{
  border: 1px solid #999;
  width: 100%;
  margin: 4px;
  cursor: pointer;
}
</style>
