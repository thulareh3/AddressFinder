<template>
  <div v-if="!!src">
    <img :src="src" alt="map type">
  </div>
</template>

<script>
export default {
  name: "image-icon",
  props: {
    src: {
      type: String,
      required: true,
      validator:(file)=>{
          
          return /\.(jpe?g|png|gif|bmp)$/i.test(file); 
      }
    },
  }
};
</script>

<style scoped>
img{
  width: 80px;
  height: 30px;
}
</style>
