<template>
  <div>
   
    <div class="info" style="height: 15%">
       <mapLayer :mapTypeData="mapTypeData" @click="changemaplayer"/>
  <span> <coordinates :coordinates="coordinates"></coordinates></span>
    </div>
    <div id="MapPanel" class="MapPanel"></div>  
    <link rel="stylesheet" :href="ref"/>
        
  </div>
</template>

<script>

import coordinates from '../coordinates/Coordinates'
import vectorpic from '/Users/Afripro2019/Desktop/addressfinder/src/assets/Vector.png'
import Hybridpic from '/Users/Afripro2019/Desktop/addressfinder/src/assets/Hybrid.jpg'

import mapLayer from '../map/ToggleMap'
import { Draggable, latLng } from 'leaflet';


export default {
  components: {coordinates,mapLayer },
  data() {
    return {
      coordinates:{latitude:-28, longitude:25},
      myMap:null,
      myMarker:null,
      mapLayer:'',
      mapTypeData: [
        { src: vectorpic, descript: "Vector" },
        { src: Hybridpic, descript: "Hybrid" }
      ],
     
    
ref:'https://unpkg.com/leaflet@1.3.1/dist/leaflet.css'
    }
  },
  mounted() {
  this.myMap=  AfriGIS.map("MapPanel", {
  zoom: 4,
  center: L.latLng(-28, 25),
  zoomControl: true,
   key: "_YOUR_KEY_HERE_",
  mapType: "Vector",
  
})
this.myMarker=L.marker([-28, 25],{draggable:true});
this.myMarker=this.myMarker.addTo(this.myMap);
this.myMarker.dragging.enable();
  },
  methods:{
addmarker(latlang,map){
this.myMarker=L.marker(latlang);
this.myMarker.addTo(map);
    },
     onDragEnd() {
var lngLat = this.myMarker.getLngLat();
this.coordinates=lngLat;
},
changemaplayer(layer){

  this.mapLayer=layer;
 this.myMap.switchTo(layer);
}
 

  },
watch:{
enableDrag(){
  let self=this;
 this.myMarker.addEventListener('dragend',function(event){
  addmarker(event.latLng,self.myMap)
   self.coordinates={latitude:-29, longitude:25};
   
}); 
this.myMarker.addTo(this.myMap);
}
},
  created(){
let self=this;
    setTimeout(function () {
          self.myMap.switchTo("Hybrid");
      }, 5000);
  } 
}
</script>
<style>
.info {
width: 90%;
height: 400px;
}
.MapPanel {
  top: 0px;
  right: 0;
  bottom: 0px;
  left: 0;
  padding: 0;
  z-index: 1;
  width: 800px;
  height: 350px;
}

</style>
