<template>
  <div>
    <button abbr title="Choose layer/style" @click="onClick">
      <slot></slot>
    </button>
  </div>
</template>


<script>
export default {
  name: "MapTypeSelector",

  methods: {
    onClick() {
      this.$emit("show-map-base");
    }
  }
};
</script>

<style>
button {
  border: 1px solid #eee;
  border-radius: 3px;
  background-color: #ffffff;
  cursor: pointer;
  font-size: 15pt;
  padding: 3px 10px;
  margin: 10px;
  transition: all ease-in-out 0.25s;
}

</style>
