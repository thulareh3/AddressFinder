<template>
    <div id="disc" v-if="descript" @click="$emit('change-mapLayers',descript)">{{descript}}</div>
</template>

<script>
export default {    
    name: 'description',
    props:{
        descript:{
            type:String,
            required:true
        }
    }
}
</script>

<style scoped>
#disc :hover{
    cursor: pointer;
}
</style>
