<template>
  <div class="container" v-if="!!coordinates">
     <longitude :longitude="coordinates.longitude"></longitude>
     <latitude :latitude="coordinates.latitude"></latitude>
</div> 

</template>
 
<script>
import longitude from './longitude.vue'
import latitude from './latitude.vue'
export default {
   name: 'Coordinates',
   components:{
     longitude,
     latitude
   },
   props:{
coordinates:
{  type: Object,
      required: true
}
    
      },
  }  ;
</script>
