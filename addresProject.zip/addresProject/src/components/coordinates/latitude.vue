<template>
 <div>
       <h3>{{latitude}}</h3>
    </div>
</template>
 
<script>
export default {
  name: "latitude",
  props: {
    latitude: {
      type: Number,
      required: true,
          }
  
   
  }
};
</script>