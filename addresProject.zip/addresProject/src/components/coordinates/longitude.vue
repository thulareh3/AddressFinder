<template>
 <div>
       <h3>{{longitude}}</h3>
    </div>
</template>
 
<script>
export default {
  name: "longitude",
  props:{
 longitude: {
      type: Number,
      required: true,
          }
  
  }
   
   
};
</script>
