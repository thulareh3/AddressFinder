<template>
  <div class="container">
    <div class="row">
      <div v-for="(adressItem,index) in popupAddress" :key="index">
        <AddressItem :long_name="adressItem.long_name.concat(',')"></AddressItem>
      </div>
    </div>
  </div>
</template>
<script>
import AddressItem from "../address/AddressItems.vue";

export default {
  name: "PopUpAddress",
  components: {
    AddressItem
  },
  props: {
    popupAddress: {
      type: Array
    }
  }
};
</script>

