<template>
  <div>
    <div v-if="!!AddressLists">
      <div v-if="AddressLists.length>0">
        <div v-for="(AddressList, index) in AddressLists" :key="index">
        <AddressSuggestionPart :AddressList="AddressList"  @goto-AdresComponent="$emit('goto-AdresComponent',$event)"/>
              
        </div>
      </div>
        <div v-else>No results found</div>
    </div>
    
  </div>
</template>

<script>

import AddressSuggestionPart from "../AddressSuggestionComponent/AddressSuggestionPart.vue";
export default {
  name: "AddressSuggestionList",
  components: {
    AddressSuggestionPart
  },
  props: {
    AddressLists: {
      type: Array,
      required: true
    }
  },
    
};
</script>

