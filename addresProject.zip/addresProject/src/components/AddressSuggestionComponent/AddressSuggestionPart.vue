<template>
<div>
    <b-list-group>
  
 <div @click="$emit('goto-AdresComponent',AddressList.formatted_Address)"> {{ AddressList.formatted_Address }}</div>
 
    </b-list-group>
</div>
    
</template>

<script>
export default {
    name:"AddressSuggestionPart",
    props:{
        AddressList:{
            type: Object,
            required:true,
            validator(value){
                return value.seoId && value.formatted_Address 
            }

        }
    },
    
}

</script>