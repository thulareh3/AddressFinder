<template>
  <div>
    <AddressDetails/>
    <Coordinates/>
  </div>
</template>
<script>
import AddressDetails from "./AddressDetails";
import Coordinates from "../coordinates/Coordinates.vue";
export default {
  name: "AddressResults",
  components: {
    AddressDetails,
    Coordinates
  }
};
</script>

