<template>
    <div>
       {{adminType}}   {{long_name}} 
    </div>
        
        
    
</template>
<script>
export default {
    name:"AddressItems",
    props:{
       Type:{
            type:String,
        },
        adminType:{
            type:String
        },
        long_name:{
            type:String,
        },
        short_name:{
            type:String,
        },
        
    }
}
</script>

