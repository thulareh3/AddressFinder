<template>
  <div>
    <div class="row" v-for="(adressItem,index) in addressDetails" :key="index">
      <div class="col-4">
        <AddressItems :adminType="adressItem.administrative_type"  :long_name="adressItem.long_name"></AddressItems>
      </div>
      <div class="col-3"></div>
    </div>
     
  </div>
</template>
<script>
import AddressItems from "./AddressItems.vue";
import Coordinates from "../coordinates/Coordinates";
export default {
  name: "AddressDetails",
  components: {
    AddressItems
  },

  props: {
    addressDetails: {
      type: Array
    }
  }
};
</script>

