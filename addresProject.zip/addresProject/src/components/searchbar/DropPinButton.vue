<template>
 
    <button
      type="button"
      data-toggle="tooltip"
      data-placement="top"
      title="show map"
      class="btn btn-default"
    @click="$emit('drop-pin')"> <i class="fas fa-map-marker-alt"></i></button>
 </template>
<script>
export default {
  name: "DropPinButton"
};
</script>

