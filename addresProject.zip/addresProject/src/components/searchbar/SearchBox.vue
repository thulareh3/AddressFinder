<template>

<form @submit.prevent="search"  v-on:keyup.prevent="$emit('key-up')">
<div class="input-group-append">
   <input type="text" v-model="text" placeholder="Search" class="form-control" @keyup="changeNcheckKeeyValue">
  <SearchSubmitButton @search="search"/>
        <DropPinButton v-on:drop-pin="$emit('drop-pin')"/>
        <span id="searchclear" v-if="text.length >0" >
         <Icon @Clear-all="clearAll"></Icon>
        </span>
 
</div>
<AdresSuggestinList :class="[removeClickedLink ? 'hide-link' : '']" :AddressLists="assigndesider ? matchingKLines : getmatchingWords"  @goto-AdresComponent=" showAddressComponent" />
<AddressDetails :addressDetails="addressPart" /> 
</form>




</template>

<script>
import Icon from "./icon";
import axios from 'axios';


import SearchSubmitButton from "./SearchSubmitButton";
import DropPinButton from "./DropPinButton";


import AdresSuggestinList from '../AddressSuggestionComponent/AddressSuggestionList'
import AddressDetails from '../address/AddressDetails';
export default {
  components:{
AdresSuggestinList,
    SearchSubmitButton,
    DropPinButton,
    Icon,
    AddressDetails
  },
  name: "SearchBox",
 data(){
  return{
    text:"",
    seoId:"",
    removeClickedLink:false,
    enterButonClickDesider:false,
    assigndesider:false,
    addressPart:[],
    tempAddresPart:[],
    errors:[],
    matchingKLines:[],
   AddressLists:[], 

  };
 },
 methods:{
   changeNcheckKeeyValue(){
     let keyKode=event.keyCode || event.which;
this.removeClickedLink=false;
if(keyKode !=13){
 this.assigndesider=false;
    }  

this.addressPart=[];
   
   },
  showAddressComponent(seoId){
 this.text=seoId;
 
 for(var i=0;i<this.tempAddresPart.length;i++){
this.addressPart.push(this.tempAddresPart[i]);
 }
this.removeClickedLink=true;
  },
search(){
  this.addressPart=[];
  this.matchingKLines=[]
   
   this.assigndesider=true;
   let strHolder=[];
   let stringString="";
    
 
  
   if(!!this.text){
    for (let i=0; i < this.AddressLists.length; i++) {
      strHolder=[];
      stringString="";
      for(let j=0;j<this.AddressLists[i].formatted_Address.length;j++){
        if(stringString.indexOf(strHolder[j])==-1){
        strHolder.push(this.AddressLists[i].formatted_Address[j])
       stringString= strHolder.join("").toLowerCase();

                     }
             }
    
  if (stringString.includes(this.text.toLowerCase())) {
        
        this.matchingKLines.push({formatted_Address:this.AddressLists[i].formatted_Address});
   }
  }
   }
  else{
    alert("please anter word to search")
  }
},
  clearAll(){
    this.text="";
      this.addressPart=[];
  }
  },
  created(){
    const addressFinderUrl=process.env.VUE_APP_ROOT_API.toString();

  axios
  .get(addressFinderUrl+'/Address')
  .then(json=>{for(var i in json.data){this.AddressLists.push(json.data[i].geocodeSearchAdress)}})
  .catch(error => console.log(error))

   axios
  .get(addressFinderUrl+'/Details')
  .then(json=>{for(var i in json.data){for(var j in json.data[i].addressComponents){this.tempAddresPart.push(json.data[i].addressComponents[j])}}})
  .catch(error => console.log(error));
 
    
  },
 computed:{
   getmatchingWords(){
     if(!!this.text){
       return this.AddressLists.filter((addressList)=>{return addressList.formatted_Address.toLowerCase().startsWith(this.text.toLowerCase());
       })
     }
     
 
  },
    

 }
  
  

  
};

</script>
<style scoped>
#searchclear {
  position: absolute;
  right: 130px;
  top: 0;
  bottom: 0;
  height: 14px;
  padding-top: 10px;
  font-size: 14px;
  cursor: pointer;
  z-index: 100;
}
.hide-link {
  display: none;
}
</style>

