<template>
    <i   class="fas fa-times" @click="$emit('Clear-all')"></i> 
</template>
<script>
export default {
    name:"Icon",
   
}
</script>
