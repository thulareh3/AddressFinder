<template>

    <button @click="$emit('search')"
      type="submit"
      data-toggle="tooltip"
      data-placement="bottom"
      title="search"
      class="btn btn-default"
    > <i class="fas fa-search"></i></button>
</template>

<script>
export default {
  name: "SearchSubmitButton"
};
</script>

<style>
</style>