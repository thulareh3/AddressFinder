import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import AddressDetails from '../src/components/address/AddressDetails'
import AddressSuggestionList from '../src/components/AddressSuggestionComponent/AddressSuggestionList'
import AddressSuggestionPart from  '../src/components/AddressSuggestionComponent/AddressSuggestionPart'

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/AddressDetails',
      name: 'AddressDetails',
      component: AddressDetails
    },
    {
      path: '/AddressSuggestionList',
      name: 'AddressSuggestionList',
      component: AddressSuggestionList,
      children:[{
        path: 'AddressSuggestionPart',
      name: 'AddressSuggestionPart',
      component: AddressSuggestionPart,
      }]
    
    },
    
    {
      path: '/about',
      name: 'about',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    }
  ]
})
