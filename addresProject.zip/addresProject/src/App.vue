
<template>
  <div id="app">
    <section class="mt-5">
      <div class="container">
        <div class="text-center">
          <h2>AfriGIS Address search Capabilities</h2>
        </div>
      </div>
    </section>
    <section id="search-bar">
      <div class="container ">
        <div class="row">
          <div class="col-md-12">
            <SearchBox  v-on:drop-pin="toggleMap"  />
            
          </div>
        </div>
      </div>
    </section>
    
    <!--v-if="showmap"
it reloads the map
    -->
    <section class="mt-5" :class="[showMap ? 'show-map' : 'hide-map']">
      <div class="container">
        <div class="map">
          <myMap></myMap>
        </div>
      </div>
    </section>
  </div>

</template>

<script>

import AddressResults from "./components/address/AddressResults";

import * as Vue2Leaflet from 'vue2-leaflet'
import ToggleMap from "./components/map/ToggleMap";
import SearchBox from "../src/components/searchbar/SearchBox";
import myMap from "../src/components/map/map"

export default {
  name: "app",
  components: { SearchBox, AddressResults, ToggleMap,myMap },
  data() {
    return {
      showMap: false,
       text:"",
      textLen:0,
      formattedAdress:"", 

    };
  },
  methods: {
    toggleMap() {
      this.showMap = !this.showMap;
    },
    

    
    
   
    
   
  
  }
};
</script>
<style>
.show-map {
  display: block;
}
.hide-map {
  display: none;
}

</style>
