/* eslint-disable import/no-extraneous-dependencies */
import { storiesOf } from '@storybook/vue'

import AddressSuggestionPart from '../components/AddressSuggestionComponent/AddressSuggestionPart.vue'

export let AddressList='';

storiesOf('AddressSuggestionPart', module)
  .add('Positive-with object consisting of seoId and formatted_Address properties', () => ({
    components: {AddressSuggestionPart },
    data(){
        return {
          AddressList:
          {
          seoId:"2XIAs5De9f_eEXNFubwV-ZXI41F281017",
          formatted_Address:"446 Rigel Avenue South, Erasmusrand, Pretoria, Gauteng, 0181"
        }
      }
    },
    template:'<AddressSuggestionPart :AddressList="AddressList"></AddressSuggestionPart>'
    
  }))
  .add('Negative-object without formatted_Address property', () => ({
    components: {AddressSuggestionPart },
    data(){
        return {AddressList:  {
          seoId:"2XIAs5De9f_eEXNFubwV-ZXI41F281017" 
        }
        }  
    },
    template:'<AddressSuggestionPart :AddressList="AddressList"></AddressSuggestionPart>'
    
  }))
  .add('Negative-object without soeid property', () => ({
    components: {AddressSuggestionPart },
    data(){
        return {AddressList:  {
          formatted_Address:"446 Rigel Avenue South, Erasmusrand, Pretoria, Gauteng, 0181" 
        }
      }
    },
    template:'<AddressSuggestionPart :AddressList="AddressList"></AddressSuggestionPart>'
    
  }))
