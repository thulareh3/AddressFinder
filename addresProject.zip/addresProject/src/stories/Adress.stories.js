import { storiesOf } from '@storybook/vue'
import AddressDetails from '../components/address/AddressDetails.vue'
import AddressItems from '../components/address/AddressItems.vue'
import PopupAddress from '../components/AddressPop/AddressPopup.vue'




export let addressDetails=[{}];
export let long_name,adminType,Type,short_name;



storiesOf('AddressDetails', module)
  .add('Positive - With an Object passed', () => ({
    components: { AddressDetails },
    data(){
return{
  addressDetails: [{
    type: "street_number",
    administrative_type: "street_number",
    long_name: "446",
    short_name: "446"
  },
  {
    type: "route",
    administrative_type: "route",
    long_name: "Rigel Avenue South",
    short_name: "Rigel Avenue South"
  },
  {
    type: "sublocality",
    administrative_type: "suburb",
    long_name: "Erasmusrand",
    short_name: "Erasmusrand"
  },
  {
    type: "locality",
    administrative_type: "town",
    long_name: "Pretoria",
    short_name: "Pretoria"
  },
  {
    type: "administrative_area_level_2",
    administrative_type: "district municipality",
    long_name: "City of Tshwane",
    short_name: "TSH"
  },
  {
    type: "administrative_area_level_1",
    administrative_type: "province",
    long_name: "Gauteng",
    short_name: "GT"
  },
  {
    type: "country",
    administrative_type: "country",
    long_name: "South Africa",
    short_name: "ZA"
  },
  {
    type: "postal_code",
    administrative_type: "post_box",
    long_name: "0165",
    short_name: "0165"
  },
  {
    type: "Street_postal_code",
    administrative_type: "post_street",
    long_name: "0181",
    short_name: "0181"
}]
};

    },
      template: '<AddressDetails :addressDetails="addressDetails"></AddressDetails>',
   }))
  .add('Negative - With no data passed', () => ({
    components: { AddressDetails },
    template: '<AddressDetails ></AddressDetails>',
   
  }));


  //stories of Address Items
  storiesOf('AddressItems', module)
  .add('Positive - With atems as strings', () => ({
    components: { AddressItems },
    data(){
return{
  long_name:"Mokopane",
  adminType:"Municipality",
  Type:"Country",
  
  short_name:"ZA",
  

};

    },
      template: '<AddressItems :Type="Type" :adminType="adminType"  :long_name="long_name" :short_name="short_name"></AddressItems>',
   }))
  .add('Negative - With no data passed', () => ({
    components: { AddressItems },
    template: '<AddressItems ></AddressItems>',
   
  }));




  //stories of poppup address
 
  storiesOf('PopupAddress ', module)
  .add('Positive - With an Object passed', () => ({
    components: { PopupAddress  },
    data(){
return{
  addressDetails: [{
    type: "street_number",
    administrative_type: "street_number",
    long_name: "446",
    short_name: "446"
  },
  {
    type: "route",
    administrative_type: "route",
    long_name: "Rigel Avenue South",
    short_name: "Rigel Avenue South"
  },
  {
    type: "sublocality",
    administrative_type: "suburb",
    long_name: "Erasmusrand",
    short_name: "Erasmusrand"
  },
  {
    type: "locality",
    administrative_type: "town",
    long_name: "Pretoria",
    short_name: "Pretoria"
  },
  {
    type: "administrative_area_level_2",
    administrative_type: "district municipality",
    long_name: "City of Tshwane",
    short_name: "TSH"
  },
  {
    type: "administrative_area_level_1",
    administrative_type: "province",
    long_name: "Gauteng",
    short_name: "GT"
  },
  {
    type: "country",
    administrative_type: "country",
    long_name: "South Africa",
    short_name: "ZA"
  },
  {
    type: "postal_code",
    administrative_type: "post_box",
    long_name: "0165",
    short_name: "0165"
  },
  {
    type: "Street_postal_code",
    administrative_type: "post_street",
    long_name: "0181",
    short_name: "0181"
},]
};

    },
      template: '<PopupAddress  :popupAddress="addressDetails"></PopupAddress >',
   }))
 
  
  













































