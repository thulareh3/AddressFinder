import { storiesOf } from '@storybook/vue'
import AddressSuggestionList from '../components/AddressSuggestionComponent/AddressSuggestionList.vue';

export let AddressLists = [];
storiesOf('Address Suggestion List', module)
.add('Positive with array of objects', () => ({
    components:{
        AddressSuggestionList
    },
    data(){
        return{
            AddressLists:[
                           {seoId: "2XIAs5De9f_eEXNFubwV-ZXI41F281017", formatted_Address:'AfriGIS 446 Rigel Ave S, Erasmusrand, Pretoria, 0181'}, 
                           {seoId: "2XIAs5De9f_eEXNFubwV-ZXI41F281018", formatted_Address:'Vodacom 245 buildning, solomon Ave S, Tembisa 1632'}, 
                           {seoId: "2XIAs5De9f_eEXNFubwV-ZXI41F281019", formatted_Address:'Transnet 4678 Mandela drive, CapeTown 3000'}, 
                           {seoId: "2XIAs5De9f_eEXNFubwV-ZXI41F281020", formatted_Address:'Telkom Mobile, Ground, 92 Oak Avenue, Highveld Park, Centurion , Centurion, Pretoria, 0157'},
                           {seoId: "2XIAs5De9f_eEXNFubwV-ZXI41F281021", formatted_Address:'Cell C Cnr Garsfontein Rd & De Villebois Mareuil Dr, Shop 4, Woodlands Boulevard, Pretorius Park, Pretoria, 0181'}
                         ]
        }        
    },
    template: '<AddressSuggestionList :AddressLists="AddressLists"></AddressSuggestionList>'
}))
.add('Positive with empty array', () => ({
    components:{
        AddressSuggestionList
    },
    data(){
        return{
            AddressLists:[]
        }
    },
    template:'<AddressSuggestionList :AddressLists="AddressLists"></AddressSuggestionList>'
}))
.add('Negative with no data passed', () => ({
    components:{
        AddressSuggestionList
    },
    template:'<AddressSuggestionList></AddressSuggestionList>'
}))



