/* eslint-disable import/no-extraneous-dependencies */
import Vue from 'vue'

import BootstrapVue from 'bootstrap-vue'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

Vue.use(BootstrapVue)

import { configure } from '@storybook/vue'

const req = require.context('../../src/stories', true, /.stories.js$/)
import VueRouter from 'vue-router'

Vue.use(VueRouter)

function loadStories() {
  req.keys().forEach(filename => req(filename))
}

configure(loadStories, module)
